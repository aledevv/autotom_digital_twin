import pandas as pd
from pathlib import Path
from .models import (
    OrganKey, OrganNode, InternodeNode, LeafNode,
    FruitsNode, RootNode, PlantSnapshot,
)


def load_snapshot_csv(csv_path: str | Path, day: int, plantid: int) -> PlantSnapshot:
    df = pd.read_csv(csv_path)
    df = df[(df["day"] == day) & (df["plantid"] == plantid)].copy()
    if df.empty:
        raise ValueError(f"No data found for day={day} and plantid={plantid}")

    snapshot = PlantSnapshot(day=day, plantid=plantid)

    for _, row in df.iterrows():
        key = OrganKey(
            day=day,
            plantid=plantid,
            order=int(row["order"]),
            rank=int(row["rank"]),
            organclass=row["organclass"],
            organindex=int(row["organindex"]),
        )
        base = dict(
            key=key,
            parentrank=int(row["parentrank"]),
            parentorganclass=row["parentorganclass"],
            agedd=float(row["agedd"]),
            drybiomassmg=float(row["drybiomassmg"]),
            aream2=float(row["aream2"]),
            length=float(row["length"]),
            isfruit=bool(row["isfruit"]),
            isroot=bool(row["isroot"]),
        )
        organclass = row["organclass"]
        if organclass == "Internode":
            node = InternodeNode(**base, widthm=float(row["internodewidthm"]))
        elif organclass == "Leaf":
            node = LeafNode(
                **base,
                lengthpetiole=float(row["leaflengthpetiole"]),
                diameterpetiole=float(row["leafdiameterpetiole"]),
                anglepetiole=float(row["leafanglepetiole"]),
                ccworientation=float(row["leafccworientation"]),
                curvature=float(row["leafcurvature"]),
                bladesnr=int(row["leafbladesnr"]),
                areabladestotal=float(row["leafareabladestotal"]),
                rachislength=float(row["leafrachislength"]),
            )
        elif organclass == "Fruits":
            node = FruitsNode(
                **base,
                fruitnr=int(row["fruitnr"]),
                fruitradii=[float(row["fruitradius0"]),
                            float(row["fruitradius1"]),
                            float(row["fruitradius2"])],
                fruitagedd=[float(row["fruitagedd0"]),
                            float(row["fruitagedd1"]),
                            float(row["fruitagedd2"])],
                ripeningdd=float(row["fruitripeningdd"]),
                trussangle=float(row["fruittrussangle"]),
            )
        elif organclass == "Root":
            node = RootNode(**base)
        else:
            raise ValueError(f"Unknown organ class: {organclass}")

        snapshot.organs.append(node)
        snapshot.bykey[key] = node
        pos = (node.key.order, node.key.rank)
        snapshot.byposition.setdefault(pos, []).append(node)

    _link_hierarchy(snapshot)
    return snapshot


def _link_hierarchy(snapshot: PlantSnapshot) -> None:
    for node in snapshot.organs:
        if node.parentrank == -1:
            continue
        for search_order in ([node.key.order] if node.key.order == 0
                              else [node.key.order, 0]):
            candidates = snapshot.byposition.get(
                (search_order, node.parentrank), [])
            parent = next(
                (c for c in candidates
                 if c.key.organclass == node.parentorganclass), None)
            if parent is not None:
                node.parent = parent
                parent.children.append(node)
                break
