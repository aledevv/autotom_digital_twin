"""
main.py  —  CLI entry point
Usage:
    python -m plant_usd_exporter  --csv plant_organs.csv  \
                                   --day 10               \
                                   --plant 1              \
                                   --out plant_day10.usda
"""
import argparse
from pathlib import Path

from .loader import load_snapshot_csv
from .usd_exporter import export_plant_usd


def main():
    parser = argparse.ArgumentParser(description="Export plant CSV to USD")
    parser.add_argument("--csv",   required=True, help="Path to plant organs CSV")
    parser.add_argument("--day",   type=int, required=True, help="Simulation day")
    parser.add_argument("--plant", type=int, default=1, help="Plant ID (default: 1)")
    parser.add_argument("--out",   required=True, help="Output .usda path")
    args = parser.parse_args()

    csv_path = Path(args.csv)
    if not csv_path.exists():
        raise FileNotFoundError(f"CSV not found: {csv_path}")

    snapshot = load_snapshot_csv(str(csv_path), day=args.day, plantid=args.plant)
    export_plant_usd(snapshot, args.out)


if __name__ == "__main__":
    main()
