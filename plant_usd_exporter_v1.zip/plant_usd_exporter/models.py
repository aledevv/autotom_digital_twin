from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional


@dataclass(frozen=True)
class OrganKey:
    """Unique identifier for an organ at a given day."""
    day: int
    plantid: int
    order: int
    rank: int
    organclass: str
    organindex: int


@dataclass
class OrganNode:
    """Base organ node — fields common to all organ types."""
    key: OrganKey
    parentrank: int
    parentorganclass: str
    agedd: float
    drybiomassmg: float
    aream2: float
    length: float
    isfruit: bool
    isroot: bool
    parent: Optional["OrganNode"] = field(default=None, repr=False)
    children: list["OrganNode"] = field(default_factory=list, repr=False)


@dataclass
class InternodeNode(OrganNode):
    """Internode — cylindrical stem segment."""
    widthm: float = 0.0


@dataclass
class LeafNode(OrganNode):
    """Compound leaf with petiole, rachis and leaflets."""
    lengthpetiole: float = 0.0
    diameterpetiole: float = 0.003  # default fallback
    anglepetiole: float = 45.0
    ccworientation: float = 0.0
    curvature: float = 0.0
    bladesnr: int = 1
    areabladestotal: float = 0.0
    rachislength: float = 0.0


@dataclass
class FruitsNode(OrganNode):
    """Fruit truss with individual fruits."""
    fruitnr: int = 0
    fruitradii: list = field(default_factory=list)
    fruitagedd: list = field(default_factory=list)
    ripeningdd: float = 0.0
    trussangle: float = 9.0


@dataclass
class RootNode(OrganNode):
    """Root — no additional geometry parameters."""
    pass


@dataclass
class PlantSnapshot:
    """All organs of a single plant at a single simulation day."""
    day: int
    plantid: int
    organs: list[OrganNode] = field(default_factory=list)
    bykey: dict[OrganKey, OrganNode] = field(default_factory=dict)
    byposition: dict[tuple, list[OrganNode]] = field(default_factory=dict)
